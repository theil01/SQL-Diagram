SET SERVEROUTPUT ON;
--Via a single SELECT query display the zip code, make, and count with the largest total car purchases for a zip code and make combination 
--(there may be a tie with two or more). 
SELECT (SELECT customers.zip
FROM customers, sales
WHERE sales.customer_id = customers.customers_id) as zippy,
(SELECT make
FROM vehicles, sales
WHERE sales.vin = vehicles.vin) as maker, COUNT(*)
FROM sales
HAVING COUNT(*) IN (SELECT COUNT(*) FROM sales)
ORDER BY COUNT(*) DESC
FETCH FIRST 1 ROWS ONLY;


--Develop a PL/SQL anonymous block that displays the total sales for a zip code for a specific zip code. 
--You may use any of your zip codes you wish.
DECLARE
zip VARCHAR(30) := '21236';
total_sales INTEGER;
BEGIN
SELECT COUNT(*) INTO total_sales
FROM sales
WHERE ID = zip;
END;

--Develop a PL/SQL anonymous block that displays the zip code with the largest total car purchases. 
--Since there can be a tie with two or more zip codes, ensure that the lowest numeric zip code is displayed
DECLARE
zipper VARCHAR(30);
BEGIN 
SELECT zip INTO zipper
from customers
HAVING COUNT(*) IN (SELECT COUNT(*)
FROM sales
WHERE customers_customer_id = sales.customer_id)
ORDER BY COUNT(*) DESC;
END;

--Create the DEALERSHIPS star schema dimension table via SQL. Add at least 2 rows of data via INSERT statement(s). 
--After populating your DEALERSHIPS table execute a "SELECT * FROM dealerships;� SQL statement to display the entire contents. 
CREATE TABLE dealerships(dealer_id PRIMARY KEY,
phone VARCHAR(20),
managers VARCHAR(20),
sq_ft INT,
region VARCHAR(30),
locations VARCHAR(30),
open_date DATE

SELECT * FROM dealerships;
--Create the VEHICLES star schema dimension table via SQL. 
--Change your existing OLTP VEHICLES table to OLTP_VEHICLES via the SQL RENAME command and change your SALES table�s foreign key 
--to reference this new table name. For the Vehicle_Code primary key column use an Oracle sequence to populate the values. 
--For the Description column use all concatenated combinations of Make and Model of vehicles you have. 
--Use a PL/SQL block to populate the Description column by SELECTing the combinations from your OLTP_VEHICLES table and then 
--INSERTing the combinations into your new VEHICLES table, which would best be performed via a cursor in a loop. 
--After populating your VEHICLES table execute a "SELECT * FROM vehicles ORDER BY vehicle_code" SQL statement to display the entire contents
ALTER TABLE vehicles RENAME oltp_vehicles;
ALTER TABLE sales DROP FOREIGN KEY (vin) REFERENCES vehicles(vin);
ALTER TABLE sales ADD FOREIGN KEY (vin) REFERENCES oltp_vehicles(vin);