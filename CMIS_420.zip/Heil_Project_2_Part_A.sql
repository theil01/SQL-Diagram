--Table Creation
CREATE TABLE customers(customer_ID INT PRIMARY KEY,
first_name VARCHAR(30) NOT NULL,
last_name VARCHAR(30)NOT NULL,
street VARCHAR(50)NOT NULL,
city VARCHAR(30)NOT NULL,
state VARCHAR(30)NOT NULL,
zip VARCHAR(30) NOT NULL
);

CREATE TABLE vehicles(vin INT PRIMARY KEY,
wholesale_cost INT NOT NULL,
wherefrom VARCHAR(30),
type VARCHAR(30) NOT NULL,
model VARCHAR(30) NOT NULL,
make VARCHAR(30) NOT NULL
);

CREATE TABLE sales(sale_ID INT PRIMARY KEY,
gsp INT,
salesperson_ID INT NOT NULL,
vin INT,    
customer_ID INT,
mileage INT NOT NULL,
dates DATE NOT NULL,
vehicle_status VARCHAR(5) DEFAULT 'NO',
FOREIGN KEY(customer_ID) REFERENCES customers(customer_ID),
FOREIGN KEY (vin) REFERENCES vehicles(vin)
--Saleperson_ID would be foreign key Referencing Saleperson Table if it was created.
);

CREATE TABLE financing(plan_ID INT,
sale_ID INT NOT NULL,
down_pay INT,
loan_term INT,
FOREIGN KEY (plan_ID) REFERENCES finplan(plan_ID),
FOREIGN KEY (sale_ID) REFERENCES sales(sale_ID)
);

CREATE TABLE finplan(plan_ID INT PRIMARY KEY,
min_down INT,
max_loan_amt INT,
institution VARCHAR(50),
percentage INT,
loan_type VARCHAR(20),
max_term INT,
FOREIGN KEY (plan_ID) REFERENCES financing(plan_ID)
);

CREATE TABLE salesperson(saleperson_ID PRIMARY KEY,
title VARCHAR(20),
first_name VARCHAR(30),
last_name VARCHAR(30),
mi VARCHAR(1),
hire_date DATE,
FOREIGN KEY (saleperson_ID) REFERENCES sales(salesperson_ID)
);
